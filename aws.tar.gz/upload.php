<?php
/**
 * Created by PhpStorm.
 * User: debasis
 * Date: 14/6/16
 * Time: 9:37 PM
 */
/*
Access Key ID:
AKIAIE5B52RHZQHDR6EQ
Secret Access Key:
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*/


require('aws-autoloader.php');

$config = array();
$config['key'] = 'AKIAIE5B52RHZQHDR6EQ';
$config['secret'] = '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';
$config['region'] = 'Oregon';


use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;
$s3Client = S3Client::factory(array(
    'credentials' => array(
        'key'    => 'AKIAIE5B52RHZQHDR6EQ',
        'secret' => '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',
    ),
    "region" => "eu-west-1",
    "version" => "latest"
));


//$s3 = Aws\S3\S3Client::factory($config);
//print_r($s3Client);

/*$result = $s3Client->listBuckets();
echo "<pre>";
print_r($result);
echo "</pre>";*/
//$s3Client->createBucket(array('Bucket' => 'mybucket'));
/*$result = $s3Client->createBucket(array(
    'Bucket'             => 'capstorage13',
    'LocationConstraint' => 'us-west-2',
));
print_r( $result);*/
/*foreach ($result['Buckets'] as $bucket) {
    // Each Bucket value will contain a Name and CreationDate
    echo "{$bucket['Name']} - {$bucket['CreationDate']}\n";
}*/


$result = $result = $s3Client->putObject(array(
    'Bucket' => 'capstorage13',
    'Key'    => 'epic-admin.png',
    'SourceFile'   => 'epic-admin.png',
    'ACL'    => 'public-read'
));

//print_r( $result);

$iterator = $s3Client->getIterator('ListObjects', array(
    'Bucket' => 'capstorage13'
));

foreach ($iterator as $object) {
    var_dump( $object);
}




